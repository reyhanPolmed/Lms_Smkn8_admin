<?php

namespace App\Filament\Resources\Teachers\Schemas;

use App\Models\User;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Section;
use Filament\Schemas\Schema;
use Illuminate\Support\Facades\Hash;

class TeacherForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Data Guru')
                    ->schema([
                        TextInput::make('name')
                            ->label('Nama Guru')
                            ->required()
                            ->maxLength(255),

                        TextInput::make('nip')
                            ->label('NIP')
                            ->required()
                            ->unique(ignoreRecord: true)
                            ->maxLength(30),

                        TextInput::make('mapel')
                            ->label('Mata Pelajaran')
                            ->required()
                            ->maxLength(100),
                    ]),

                Section::make('Akun Login Guru')
                    ->schema([
                        TextInput::make('password')
                            ->label('Password Login')
                            ->password()
                            ->required(fn ($record) => $record === null)
                            ->dehydrateStateUsing(fn ($state) => filled($state)
                                ? Hash::make($state)
                                : null
                            )
                            ->afterStateHydrated(fn ($component) => $component->state(''))
                            ->saveRelationshipsUsing(
                                function ($state, $record) {
                                    if ($state && !$record->user) {
                                        $user = User::create([
                                            'identifier' => $record->nip,
                                            'password'   => $state,
                                            'role'       => 'teacher',
                                        ]);

                                        $record->user()->associate($user)->save();
                                    }
                                }
                            ),
                    ]),
            ]);
    }
}
